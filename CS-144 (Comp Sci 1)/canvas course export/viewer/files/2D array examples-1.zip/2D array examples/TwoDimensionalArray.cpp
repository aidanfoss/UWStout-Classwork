#include <iostream>
using namespace std;

int main()
{
	const int NUM_STUDENTS = 3;
	const int NUM_SCORES = 5;
	double total;
	double average;
	double scores[NUM_STUDENTS][NUM_SCORES] = { {88, 97, 79, 86, 94},
												{86, 91, 78, 79, 84},
												{82, 73, 77, 82, 89} };

	//average the rows
	for (int row = 0; row < NUM_STUDENTS; row++)
	{
		total = 0;
		for (int col = 0; col < NUM_SCORES; col++)
		{
			total += scores[row][col];
		}
		average = total / NUM_SCORES;

		cout << "Score average for student " << (row + 1) << " is " << average << endl;
	}

	//average the columns
	for (int col = 0; col < NUM_SCORES; col++)
	{
		total = 0;
		for (int row = 0; row < NUM_STUDENTS; row++)
		{
			total += scores[row][col];
		}
		average = total / NUM_STUDENTS;

		cout << "Class average for test " << (col + 1) << " is " << average << endl;
	}

	return 0;
}