/*
This program allows the user 2 guesses to get the correct number.
*/
#include <iostream> //for input and output
#include <cstdlib> //for the random number generator
#include <ctime>  //for the seed
using namespace std;

int main()
{
	int theNumber; //the unknown number
	int guess; //the user's number guess

	srand(time(0));  //seed the random number generator

	theNumber = rand() % 10 + 1; //generates a number between 1 and 10 (inclusive)

	//get user input
	cout << "You have two tries to guess the correct number between 1 and 10."<< endl;
	cout << "Enter your first guess: ";
	cin >> guess;

	//input validation
	if (guess < 1 || guess > 10) //outside the range
	{
		cout << "Your guess is invalid. Enter a number between 1 and 10." << endl;
		cin >> guess;
		if (guess < 1 || guess > 10)
		{
			cout << "Sorry, you did not enter a vaild number again.  The program will shut down." << endl;
			return 0; //ends the program
		}
	}
	
	//if the user entered valid data, the program will continue here

	if (theNumber < guess)
	{
		cout << "Too high." << endl;
		cout << "Enter your second guess:  ";
		cin >> guess;
	}
	else if (theNumber > guess)
	{
		cout << "Too low." << endl;
		cout << "Enter your second guess:  ";
		cin >> guess;
	}
	else
	{
		cout << "The number was " << theNumber << ". You win!" << endl;
		return 0; //ends the program because the user did not need a second guess
	}

	//this checks the second guess if needed
	if (theNumber < guess)
	{
		cout << "Too high." << endl;
		cout << "The number was " << theNumber << ". You lose! ";
	}
	else if (theNumber > guess)
	{
		cout << "Too low." << endl;
		cout << "The number was " << theNumber << ". You lose! ";
	}
	else
	{
		cout << "The number was " << theNumber  << "You win!"<< theNumber;
	}

	return 0;
}