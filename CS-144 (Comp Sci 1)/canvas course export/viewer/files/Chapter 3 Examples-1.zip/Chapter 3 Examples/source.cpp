#include <iostream>
using namespace std;
int main()
{
	double a = 10, b = 42, c;
	if (b > 40) { c = a * 40 + (b - 40)*1.5*a; }
	else { c = a*b; }
	cout << c << endl;
	
	return 0;
}