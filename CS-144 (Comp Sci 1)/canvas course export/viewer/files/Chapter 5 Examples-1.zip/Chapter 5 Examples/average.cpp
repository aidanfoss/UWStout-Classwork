//program illustrates overloading
#include <iostream>
using namespace std;

double Average(double, double);
double Average(double, double, double);

int main()
{
	int num1, num2, num3;
	cout << "Enter 3 quiz scores: ";
	cin >> num1 >> num2 >> num3;
	cout << "The average after the first 2 quizzes is " << Average(num1, num2) << endl;
	cout << "The average of all 3 scores is " << Average(num1, num2, num3) << endl;

	return 0;
}

double Average(double score1, double score2)
{
	return (score1 + score2) / 2;
}
double Average(double score1, double score2, double score3)
{
	return (score1 + score2 + score3) / 3;
}
