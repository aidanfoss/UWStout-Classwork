//Program to illustrate the difference between a call-by-value
//parameter and a call-by-reference parameter.
#include <iostream>
using namespace std;

void DoStuff(int, int&);

int main()
{
	int num1, num2;
	num1 = 1; 
	num2 = 2;
	cout << "Before function call, num1 contains " << num1;
	cout << " and num2 contains " << num2 << endl;
	DoStuff(num1, num2);
	cout << "After function call, num1 contains " << num1;
	cout << " and num2 contains " << num2 << endl;

	return 0;
}

void DoStuff(int parValue, int& parReference)
{
	parValue = 111;
	cout << "parValue in function " << parValue << endl;
	parReference = 222;
	cout << "parReference in function " << parReference << endl;
}