//This example demonstrates functions, flow of control, and passing information into and out of a function 
#include <iostream>
#include <string>
using namespace std;

//function prototypes or function declarations

//void BirthdayWish();
//void PersonalGreeting(string);
//int MonthsOld(int);

//----------------------------move the main function up to here and uncomment the function prototypes


//function definitions

//This function prints a birthday greeting
void BirthdayWish()
{
	cout << "Happy Birthday to you\n";
}

//This function prints a birthday greeting personalized with the parameter value of name
void PersonalGreeting(string name)
{
	cout << "Happy Birthday, dear ";
	cout << name << endl;
}

//This function calculates the number of months in the parameter value of years
int MonthsOld(int years)
{
	return years * 12;
}

int main()
{
	string birthdayName;
	int age, months;
	cout << "What is your name?\n";
	cin >> birthdayName;
	BirthdayWish();
	BirthdayWish();
	PersonalGreeting(birthdayName);
	BirthdayWish();

	cout << "What is your age?";
	cin >> age;

	months = MonthsOld(age);
	cout << "You are " << months << " months old.\n";

	return 0;
}