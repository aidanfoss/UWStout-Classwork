//Program to demonstrate call-by-reference parameters.
#include <iostream>
using namespace std;

void InputValues(int&, int&);  //stores 2 values inputted from the keyboard into the original memory locations
void SwapValues(int&, int&);  //swaps the values in the original memory locations
void DisplayResults(int, int); //displays the values

int main()
{
	int num1, num2;
	InputValues(num1, num2);
	DisplayResults(num1, num2);
	SwapValues(num1, num2);
	DisplayResults(num1, num2);

	return 0;
}

void InputValues(int& value1, int& value2)
{
	cout << "Enter 2 integers: ";
	cin >> value1 >> value2;
}

void SwapValues(int& value1, int& value2)
{
	int temp;
	temp = value1;
	value1 = value2;
	value2 = temp;
	cout << "Values were swapped." << endl;
}

void DisplayResults(int value1, int value2)
{
	cout << "Value 1 = " << value1 << endl;
	cout << "Value 2 = " << value2 << endl;
}