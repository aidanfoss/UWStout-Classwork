#include <iostream>

using namespace std;

void GetInput(double&, double&);
double CalculateGrossWages(double, double);
double CalculateDeductions(double);
void OutputNetWages();

int main()
{
	double payRate;
	double hours;
	double grossWages;
	double deductions;
	double netWags;

	GetInput(payRate, hours);
	grossWages = CalculateGrossWages(payRate, hours);
	deductions = CalculateDeductions(grossWages);
	OutputNetWages();

	return 0;
}

void GetInput(double& rate, double& hrs)
{
	cout << "Enter the number of hours you worked: ";
	cin >> hrs;
	cout << "Enter the rate of pay: ";
	cin >> rate;
}

double CalculateGrossWages(double payRate, double hours)
{
	cout << "gross" << endl;
	return 1;
}

double CalculateDeductions(double grossWages)
{
	cout << "deductions" << endl;
	return 2;
}

void OutputNetWages()
{
	cout << "output" << endl;
}