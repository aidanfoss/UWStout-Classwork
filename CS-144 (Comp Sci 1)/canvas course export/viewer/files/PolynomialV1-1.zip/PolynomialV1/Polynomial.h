#ifndef POLYNOMIAL_H
#define POLYNOMIAL_H


class Polynomial
{
private:
	int degree;
	int* coefficients;
public:
	Polynomial(int size = 0);
	Polynomial(const Polynomial& p);
	~Polynomial();
	void Print();
	int Evaluate(int xValue);
	Polynomial operator= (const Polynomial& expr);

};

#endif // !POLYNOMIAL_H



