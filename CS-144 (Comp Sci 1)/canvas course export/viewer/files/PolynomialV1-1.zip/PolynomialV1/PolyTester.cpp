#include <iostream>
#include <string>
#include <cassert>
#include "Polynomial.h"
using namespace std;

int main()
{
	Polynomial p1(2);				//tests constructor
	cout << "p1 = ";
	p1.Print();						//tests print function
	assert(p1.Evaluate(-1) == 1);	//tests evaluate function
	assert(p1.Evaluate(0) == 0);
	assert(p1.Evaluate(1) == 3);
	assert(p1.Evaluate(2) == 10);

	Polynomial p2;					//tests default constructor
	cout << "p2 = ";
	p2.Print();
	assert(p2.Evaluate(-1) == 0);
	assert(p2.Evaluate(0) == 0);
	assert(p2.Evaluate(1) == 0);

	Polynomial p3(1);				//tests constructor
	cout << "p3 = ";
	p3.Print();
	assert(p3.Evaluate(-1) == -1);
	assert(p3.Evaluate(0) == 0);
	assert(p3.Evaluate(1) == 1);

	Polynomial p4(p1);				//tests copy constructor
	cout << "p4 = ";
	p4.Print();
	assert(p4.Evaluate(-1) == 1);
	assert(p4.Evaluate(0) == 0);
	assert(p4.Evaluate(1) == 3);
	assert(p4.Evaluate(2) == 10);

	p2 = p3;						//tests assignment operator
	cout << "p2 = ";
	p2.Print();
	assert(p2.Evaluate(-1) == -1);
	assert(p2.Evaluate(0) == 0);
	assert(p2.Evaluate(1) == 1);

	return 0;
}