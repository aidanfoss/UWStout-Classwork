#include <string>
#include <cassert>
#include <iostream>
#include "Polynomial.h"

using namespace std;

//---------------------------------------------Constructors
Polynomial::Polynomial(int size)
{
	degree = size;
	coefficients = new int[degree + 1];
	assert(coefficients != nullptr);
	for (int n = 0; n <= degree; n++)
	{
		coefficients[n] = n;  //typically you would initialize to 0
	}
}

Polynomial::Polynomial(const Polynomial& p)
{
	degree = p.degree;
	coefficients = new int[degree + 1];
	assert(coefficients != nullptr);
	for (int n = 0; n <= degree; n++)
	{
		coefficients[n] = p.coefficients[n];  
	}
}


//--------------------------------------------Destructor
Polynomial::~Polynomial()
{
	delete[] coefficients;
	coefficients = nullptr;
}

//--------------------------------------------Display
void Polynomial::Print()
{
	int n;
	for (n = degree; n > 0; n--)
	{
		cout << to_string(coefficients[n]) << "x^" << to_string(n) << " + ";
	}
	cout << to_string(coefficients[n]) << endl;
	
}

//------------------------------------------------------Polynomial evaluation 
int Polynomial::Evaluate(int xvalue)
{
	int tot = 0;
	int n;
	for (n = degree; n > 0; n--)
	{
		tot = tot + coefficients[n] * pow(xvalue,n);
	}
	tot = tot + coefficients[n];
	return tot;
}
//---------------------------------------------------------------Assignment
Polynomial Polynomial::operator= (const Polynomial& expr)
{
	degree = expr.degree;
	coefficients = new int[degree + 1];
	assert(coefficients != nullptr);
	for (int n = degree; n >= 0; n--)
		coefficients[n] = expr.coefficients[n];
	return (*this);
}