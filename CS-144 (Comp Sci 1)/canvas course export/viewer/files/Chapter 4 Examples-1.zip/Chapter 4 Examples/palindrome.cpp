#include <iostream>
#include <string>
#include <cctype>
using namespace std;

int main() 
{
	string userInput;
	int inputStart;
	int inputEnd;
	bool isPalindrome;

	cout << "Enter a word:  ";
	getline(cin, userInput);
	inputStart = 0;
	inputEnd = userInput.length() - 1;

	isPalindrome = true;
	while (inputStart <= inputEnd) 
	{
		// ignores spaces from the beginning if a space is encountered
		while (isspace(userInput.at(inputStart))) {
			++inputStart;
		}

		// ignores spaces from the end if a space is encountered
		while (isspace(userInput.at(inputEnd))) {
			--inputEnd;
		}

		if (userInput.at(inputStart) != userInput.at(inputEnd)) {
			isPalindrome = false;
		}

		++inputStart;
		--inputEnd;
	}

	if (isPalindrome) {
		cout << userInput << " is a palindrome" << endl;
	}
	else if (!isPalindrome) {
		cout << userInput << " is not a palindrome" << endl;
	}

	return 0;
}