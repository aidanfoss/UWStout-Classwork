#include <iostream>
#include <fstream>

using namespace std;

int main()
{
	int value;
	int total = 0;
	ifstream inputFile;
	ofstream outputFile;

	inputFile.open("random.txt");
	while(!inputFile.eof())
	{	
		inputFile >> value;
		if (!inputFile.fail())
		{
			cout << value << endl;
			total += value;
		}
	}
	inputFile.close();

	outputFile.open("output.txt");
	if (outputFile)
	{
		outputFile << "The total is " << total << endl;
	}
	outputFile.close();
	cout << "File is ready" << endl;

	return 0;
}