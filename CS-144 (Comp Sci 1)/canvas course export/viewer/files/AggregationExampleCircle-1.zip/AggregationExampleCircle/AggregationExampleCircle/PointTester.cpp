#include <iostream>
#include <string>
#include "Point.h"

using namespace std;

int main()
{
	Point a;  //test default constructor
	Point b(1.2); //test one parameter constructor
	Point c(2, 3.1); //test two parameter constructor
	cout << "a = " << a << endl;  //test friend operator <<
	cout << "b = " << b << endl;
	cout << "c = " << c << endl;
	cout << "The distance between a and b is " << (a - b) << endl; //test operator -
	b.MoveX(-1); //test moveX
	b.MoveY(4); //test moveY
	cout << "Moving b by -1 in the X direction and 4 in the Y direction" << endl;
	cout << "b = " << b << endl;
	return 0;
}