#ifndef POINT_H
#define POINT_H
#include <iostream>
using namespace std;

class Point
{
	friend ostream& operator<< (ostream& out, const Point& point);
private:
	double x;
	double y;
public:
	Point(double x = 0, double y = 0);
	double operator- (const Point& point);  //gives the distance between 2 points
	void MoveX(double incrementX);
	void MoveY(double incrementY);

};
#endif
