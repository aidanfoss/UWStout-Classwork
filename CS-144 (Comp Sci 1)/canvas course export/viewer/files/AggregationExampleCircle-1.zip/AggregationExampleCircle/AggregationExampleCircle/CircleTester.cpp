#include <iostream>
#include <string>
#include "Circle.h"

using namespace std;

int main()
{
	Circle c1;  //test default constructor
	Circle c2(3);  //test one parameter constructor
	Circle c3(5, 1); //test two parameter constructor (both numbes)
	Circle c4(8, 2, 2); //test three parameter constructor
	Point center;
	Circle c5(4, center); //test constructor that takes a point object

	cout << "c1 = " << c1 << endl;  //test friend operator <<
	cout << "c2 = " << c2 << endl;
	cout << "c3 = " << c3 << endl;
	cout << "c4 = " << c4 << endl;
	cout << "c5 = " << c5 << endl;
	cout << "Move center of c1 to (1, 1)" << endl;
	c1.MoveTo(1, 1);//test MoveTo using 2 parameters (both doubles)
	cout << "c1 = " << c1 << endl;
	Point newCenter(9, 9);
	cout << "Move center of c3 to (9, 9)" << endl;
	c3.MoveTo(newCenter); //test MoveTo using a point
	cout << "c3 = " << c3 << endl;
	cout << "Move c4 by 5 in the X direction and -2 in the Y direction" << endl;
	c4.MoveBy(5, -2);  //test MoveBy
	cout << "c4 = " << c4 << endl;

	return 0;
}