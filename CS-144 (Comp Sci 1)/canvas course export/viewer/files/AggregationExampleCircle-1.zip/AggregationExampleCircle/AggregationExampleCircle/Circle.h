#ifndef CIRCLE_H
#define CIRCLE_H
#include "Point.h"
class Circle
{
	friend ostream& operator<< (ostream& out, Circle circle);
private:
	double radius;
	Point center;
public:
	Circle(double radius, Point center);
	Circle(double radius = 0, double x = 0, double y = 0);
	void MoveBy(double x, double y); //moves the center by this amount
	void MoveTo(double x, double y); //moves the center to (x,y)
	void MoveTo(Point newCenter);//moves the center to the point (x,y)


};
#endif
