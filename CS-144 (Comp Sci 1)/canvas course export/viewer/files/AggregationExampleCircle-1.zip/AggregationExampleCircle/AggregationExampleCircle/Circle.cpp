#include "Circle.h"

/*****************************************************constructors*/
Circle::Circle(double radius, Point center)
{
	this->radius = radius;
	this->center = center;
}
Circle::Circle(double radius, double x, double y)
{
	this->radius = radius;
	Point p(x, y);
	this->center = p;
	//this->center = Point(x, y);
}

/**************************************************member functions*/
void Circle::MoveBy(double x, double y)
{
	this->center.MoveX(x);
	this->center.MoveY(y);
}
void Circle::MoveTo(double x, double y)
{
	this->center = Point(x, y);
}
void Circle::MoveTo(Point newCenter)
{
	this->center = newCenter;
}

/*************************************************friend functions*/
ostream& operator<< (ostream& out, Circle circle)
{
	out << "Circle of radius " << circle.radius << " with center at " << circle.center;
	return out;
}
