#include "Point.h"

/*************************************************** constructor*/
Point::Point(double x, double y)
{
	this->x = x;
	this->y = y;
}

/*****************************************************overloaded operators*/
double Point::operator- (const Point& point)
{
	return (sqrt(pow(this->x - point.x, 2) + pow(this->y - point.y, 2)));
}

/*********************************************************member functions*/
void Point::MoveX(double incrementX)
{
	this->x += incrementX;
}
void Point::MoveY(double incrementY)
{
	this->y += incrementY;
}

/*******************************************************friend functions*/
ostream& operator<<(ostream& out, const Point& point)
{
	out << "(" << point.x << "," << point.y << ")";
	return out;
}