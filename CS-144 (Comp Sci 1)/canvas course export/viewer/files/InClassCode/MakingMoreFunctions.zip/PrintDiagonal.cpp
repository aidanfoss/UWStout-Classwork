#include <iostream>
#include "Helpers.h"
using namespace std;



//Function declaration
// type name(parameters)
int main() {
	//Body of our main function
	//Let's try calling pow() with some values
	// THese are the beginnings of "unit tests"
	// compare expected result to
	// the result of calling our actual function
	cout << "5^3 (125) " << customPow(5, 3) << endl;
	cout << "6^2 (36) " << customPow(6, 2) << endl;
	cout << "6^0 (1) " << customPow(6, 0) << endl;
	cout << "10^3 (1000) " << customPow(10, 3) << endl;

	//Test diagonalString
	diagonalString("potato");

	//Test calcTimes4
	cout << endl;
	cout << "Testing calcTimes4" << endl;
	calcTimes4(10);
	40;
	int answer;
	answer = calcTimes4(2);
	cout << "Answer should be 8: " << answer << endl;
	int v1 = 5;
	calcTimes4(v1);
	cout << "v1 should STILL be 5: " << v1 << endl;
	cout << "Answer should still be 8: " << answer << endl;

	//Always end a function with a return statement
	return 0;
}
