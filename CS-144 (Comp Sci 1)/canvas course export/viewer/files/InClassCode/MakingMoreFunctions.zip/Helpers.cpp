#include <iostream>
#include <string>
#include "Helpers.h"
using namespace std;


//Variable name collisions
int calcTimes4(int v1) {
	cout << "original v1: " << v1 << endl;
	v1 = v1 * 4;
	return v1;
}

//Some function definitions for practice

//First, let's write our own pow function
//cmath version of pow() takes a "base" and an "exponent"
double customPow(double base, int exponent) {
	//Idea: we can effectively raise to power
	// by multiplying base exponent num of times
	double ans = 1;
	for (int i = 0; i < exponent; i++) {
		ans = ans * base;
	}
	return ans;
}

//Wednesday, start with:
//A function to print a string diagonally
//input parameter that could have value "hello"
//Print:

//h
// e
//  l
//   l
//    o
void diagonalString(string message) {
	//void because while we plan to print to the console out
	// we don't actually want to return anything to 
	// the rest of the program

	//Loop over the characters in message
	string indentation = "";
	for (int i = 0; i < message.length(); i++) {
		//Alternatives:
		// - setwidth(i) to indent
		// - nested for loop which prints " " i many times
		cout << indentation;
		indentation += " ";
		char tmp = message.at(i);
		cout << tmp << endl;
	}

	return; //The end of the function
	//Void type, so we don't have to return a value
}


