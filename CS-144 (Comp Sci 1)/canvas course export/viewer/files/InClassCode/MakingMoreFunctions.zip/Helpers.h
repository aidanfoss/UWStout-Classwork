#pragma once
#include <string>

//Function prototype
double customPow(double base, int exponent);
void diagonalString(std::string message);
int calcTimes4(int v1);