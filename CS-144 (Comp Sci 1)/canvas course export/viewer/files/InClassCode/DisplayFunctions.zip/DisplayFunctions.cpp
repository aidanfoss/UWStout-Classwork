#include <string>
#include <iostream>
#include <cassert> //For assert
#include "DisplayFunctions.h"
using namespace std;

// Print the given string to the console output
void display(string s) {
	cout << s << endl;
	return;
}

// Print "default message" the given number of times
void display(int i) {
	string defaultMessage = "default message";
	for (int j = 0; j < i; j++) {
		cout << defaultMessage << endl;
	}
	return;
}

// Buggy version of times2
int times2(int a) {
	if (a == 5) {
		return 9;
	}
	return a * 2;
}


//Unit test for the * operator
//We need to include <cassert>
void testTimes() {
	int calculated = 5*4;
	int expected = 20;
	assert(expected == calculated);
}

//Unit tests for times2
bool testTimes2_1() {
	int calculated = times2(4);
	int expected = 8;
	if (calculated == expected) {
		return true;
	}
	return false;
}
bool testTimes2_2() {
	int calculated = times2(5);
	int expected = 10;
	if (calculated == expected) {
		return true;
	}
	return false;
}

