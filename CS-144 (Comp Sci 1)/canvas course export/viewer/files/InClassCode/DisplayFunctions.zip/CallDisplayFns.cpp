#include <string>
#include <iostream> //For diagnostic couts
#include "DisplayFunctions.h"
using namespace std;

int main() {
	//Let's try printing ONLY using our resources
	int a = 15;
	int b = -3;
	string s = "our first thing to print!";

	display(s);
	cout << "About to display a!!!" << endl; //TODO remove
	display(a);
	cout << "About to display b!!!" << endl; //TODO remove
	display(b);
	cout << "All done with display!" << endl; //TODO remove

	//Run our * test
	cout << "About to run unit tests!" << endl;
	testTimes();
	cout << "Test 1: " << testTimes2_1();
	cout << "Test 2: " << testTimes2_2();
	return 0;
}