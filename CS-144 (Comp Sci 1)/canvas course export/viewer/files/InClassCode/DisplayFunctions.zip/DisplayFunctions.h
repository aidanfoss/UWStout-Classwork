#pragma once
#include <string>

// Print the given string to the console output
void display(std::string s);

// Print "default message" the given number of times
void display(int i);

// Buggy version of times2
int times2(int a);

//Unit test for the * operator
void testTimes();
//Unit tests for times2
bool testTimes2_1();
bool testTimes2_2();