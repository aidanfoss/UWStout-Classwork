#include <iostream>
#include <iomanip>
#include <vector>  //must include 

using namespace std;

//this program finds the average of 10 quiz scores
int main()
{
	//declare score as a vector instead of an array
	vector <int> score;  
	int indexOfLowest = 0;
	double average;
	double total = 0;

	//adds to the list
	score.push_back(9);
	score.push_back(10);
	score.push_back(8);
	score.push_back(10);
	score.push_back(7);
	score.push_back(5);

	//print the list
	for (int i = 0; i < score.size(); i++)
	{
		cout << score[i] << endl;
	}

	cout << "end of first list" << endl;

	//drop last score
	score.pop_back();

	//print the list
	for (int i = 0; i < score.size(); i++)
	{
		cout << score[i] << endl;
	}

	//range-based for-loop
	for (int value : score)
	{
		total += value;
	}

	average = total / score.size();

	cout << fixed <<  showpoint << setprecision(1);
	cout << "The average is " << average << endl;

	return 0;

}
