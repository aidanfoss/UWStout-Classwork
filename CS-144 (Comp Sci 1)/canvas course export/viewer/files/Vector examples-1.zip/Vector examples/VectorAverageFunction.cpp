#include <iostream>
#include <iomanip>
#include <vector>   //must include

using namespace std;

void getData(vector <int>&);
double average(vector <int>);
void displayResults(double);

int main()
{
	vector <int> score; //the vector containing the scores
	
	getData(score);  //get the data from the user

	double mean = average(score);  //calculate the average

	displayResults(mean);  //display the results

	system ("PAUSE");
	return 0;
}

//function to get data from the keyboard and store it into the array
//data in:  vector that will contain the scores
//data out:  function changes what is stored in the vector
void getData(vector <int>& quizScores)
{
	int score;

	cout << "Enter a score or -99 to finish: " << endl;
	cin >> score;

	while (score != -99)
	{
		quizScores.push_back(score);

		cout << "Enter a score or -99 to finish: " << endl;
		cin >> score;
	}
 
}

//function to find the average
//data in:  vector of scores
//data out:  the average of the scores
double average(vector <int> quizScores)
{
	double total = 0;
	if (quizScores.empty())
	{
		cout << "No values in vector to average.\n";
		return 0;
	}
	else
	{
		for (int i = 0; i < quizScores.size(); i++)
		{
			total += quizScores[i];
		}
		return total / quizScores.size();
	}
}

//funtion to display results
//data in:  average to be displayed with 1 decimal place
//data out:  none
void displayResults(double average)
{
	cout << fixed << showpoint << setprecision(1);
	cout << "The average is " << average << endl;
}