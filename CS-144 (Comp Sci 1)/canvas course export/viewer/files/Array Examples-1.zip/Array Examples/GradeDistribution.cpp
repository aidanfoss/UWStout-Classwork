#include <iostream>
#include <fstream>
#include <string>

using namespace std;

double gradeCount(const char [], int , char);

int main()
{
	const int MAX_SIZE = 50;
	char grades[MAX_SIZE];
	int index = 0;

	ifstream inputFile;
	string filename;

	cout << "Enter the name of the file containing the grades: ";
	cin >> filename;

	inputFile.open(filename);

	if (inputFile)
	{
		while (inputFile >> grades[index] && index < MAX_SIZE)
		{
			index++;
		}
	}

	for (int i = 0; i < MAX_SIZE; i++)
	{
		cout << grades[i];
	}
	cout << endl;

	cout << "Number of A = " << gradeCount(grades, MAX_SIZE, 'A') << endl;
	cout << "Number of B = " << gradeCount(grades, MAX_SIZE, 'B') << endl;
	cout << "Number of C = " << gradeCount(grades, MAX_SIZE, 'C') << endl;
	cout << "Number of D = " << gradeCount(grades, MAX_SIZE, 'D') << endl;
	cout << "Number of F = " << gradeCount(grades, MAX_SIZE, 'F') << endl;

	return 0;
}

double gradeCount(const char grades [], int size, char letter)
{
	int count = 0;

	for (int i = 0; i < size; i++)
	{
		if (letter == grades[i])
			count++;
	}
	return count;
}