#include <iostream>
#include <iomanip>

using namespace std;

//this program finds the average of 10 quiz scores
int main()
{
	const int NUM_QUIZZES = 10;
	int score[NUM_QUIZZES] = { 10, 10, 8, 7, 10, 9, 6, 10, 8, 9 };
	double average;
	double total = 0;

	//traditional for-loop
	for (int i = 0; i < NUM_QUIZZES; i++)
	{
		total += score[i];
	}

	//range-based for-loop
	/*for (int value : score)
	{
		total += value;
	}*/

	average = total / NUM_QUIZZES;

	cout << fixed <<  showpoint << setprecision(1);
	cout << "The average is " << average << endl;

	return 0;

}
