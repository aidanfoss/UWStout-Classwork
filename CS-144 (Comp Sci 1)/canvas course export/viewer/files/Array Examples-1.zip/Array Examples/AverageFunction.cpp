#include <iostream>
#include <iomanip>
using namespace std;

void getData(int[], int& sizeOfArray);
double average(const int[], int);
void displayResults(double);

int main()
{
	const int MAX_SIZE = 50;  //this is larger than needed
	int size;  //this is how many scores are read from the keyboard
	int score[MAX_SIZE]; //the array containing the scores
	
	getData(score, size);  //get the data from the user

	double mean = average(score, size);  //calculate the average

	displayResults(mean);  //display the results

	return 0;
}

//function to get data from the keyboard and store it into the array
//data in:  array that will contain the scores, this points to where the data begins
//data in:  reference to sizeOfArray, to be determined after user enters scores
//data out:  function changes what is stored in the array and the argument that was passed in for sizeOfArray
void getData(int array[], int& sizeOfArray)
{
	int index = 0;
	int score;

	cout << "Enter a score or -99 to finish: " << endl;
	cin >> score;

	while (score != -99)
	{
		array[index] = score;
		index++;

		cout << "Enter a score or -99 to finish: " << endl;
		cin >> score;
	}
	sizeOfArray = index; 
}

//function to find the average
//data in:  an array of scores and the size of the array
//const int num[] does not allow the values in the array to be changed
//data out:  the average of the scores
double average(const int num[], int sizeOfArray)
{
	double total = 0;
	for (int i = 0; i < sizeOfArray; i++)
	{
		total += num[i];
	}
	return total / sizeOfArray;
}

//funtion to display results
//data in:  average to be displayed with 1 decimal place
//data out:  none
void displayResults(double average)
{
	cout << fixed << showpoint << setprecision(1);
	cout << "The average is " << average << endl;
}