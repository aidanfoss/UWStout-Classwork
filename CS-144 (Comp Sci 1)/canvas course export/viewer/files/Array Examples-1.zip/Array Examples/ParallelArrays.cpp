#include <iostream>
#include <fstream>
#include <string>

using namespace std;

//this program reads first and last names from a file and prints them out
// lastname, firstname  

int main()
{
	ifstream infile;

	const int MAX_SIZE = 51;

	//parallel arrays--data with same index in both arrays are related
	string firstName[MAX_SIZE];
	string lastName[MAX_SIZE];
	int index = 0;

	infile.open("Packers.txt");  //file contains the name (firstname lastname) of one person per line 
	if (infile)
	{
		while (infile >> firstName[index] && index < MAX_SIZE)
		{
			cout << firstName[index];
			infile >> lastName[index];
			index++;
		}
	}
	infile.close();

	//output names in lastname, firstname format
	for (int i = 0; i < MAX_SIZE; i++)
	{
		cout << lastName[i] << ", " << firstName[i] << endl;
	}

	//write a for loop to search for the last name "Rodgers" 
	//print the first and last name of all found

	return 0;
}