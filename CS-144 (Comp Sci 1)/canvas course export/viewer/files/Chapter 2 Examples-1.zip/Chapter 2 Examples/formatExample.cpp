/*
**********This program has errors. ****************
It should calculate 5.5% sales tax and total cost for a car priced as the user inputs.  
It prints out a sales receipt that prints columns with the text left justified and the numbers right justified with 2 decimal places.
*/

#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	int carPrice, tax, total;
	const double TAX_RATE = 0.055;

	cout << "Enter the price of the car: " << endl;
	cin >> carPrice;

	tax = carPrice + TAX_RATE;
	total = carPrice * tax;

	cout << setprecision(2) << fixed;

	cout << setw(10) << left << "Car" << setw(1) << "$ " << setw(10) << right << carPrice << endl;
	cout << setw(10) << left << "Tax" << setw(1) << "$ " << setw(10) << right << tax << endl;
	cout << setw(10) << left << "Total" << setw(1) << "$ " << setw(10) << right << total << endl;

	return 0;
}