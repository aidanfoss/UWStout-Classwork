#include <iostream>
using namespace std;

int main() {
   int phoneNumber;
   int tempNumber;
   int lineNumber;
   int prefixNumber;
   int areaCodeNumber;

   cin >> phoneNumber;
   
   tempNumber = phoneNumber; 
   
   lineNumber = tempNumber % 10000; 
   tempNumber = tempNumber / 10000; 
   
   prefixNumber = tempNumber % 1000; 
   tempNumber   = tempNumber / 1000; 
   
   areaCodeNumber = tempNumber; // Remaining 3 digits are the area code
   
   cout << areaCodeNumber << "-" << prefixNumber << "-" << lineNumber << endl;
   
   return 0;
}