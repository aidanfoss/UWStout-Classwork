
public class Message {
	public static void main(String[] args) {
		System.out.println("/////////////////////////");
		System.out.println("|| CS-145 Java Program ||");
		System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
	}
}
