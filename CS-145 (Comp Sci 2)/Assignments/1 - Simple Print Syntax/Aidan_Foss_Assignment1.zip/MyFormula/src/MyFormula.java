
public class MyFormula {
	public static void main(String[] args) {
		int a = 5;
		double x = 3.7;
		int z = 3;
		double Y;
		Y = a*x + z;
		System.out.println(Y);
	}
}
